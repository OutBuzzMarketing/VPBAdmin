import React, { Component } from 'react';

class Table extends Component {
    render() {
        return (
            <section className="table">
                <div className="table-content">
                   Stationery Testing
                </div>
            </section>
        );
    }
}

export default Table;