import React, { Component } from "react";
 
class Footer extends Component {
  render() {
    return (
      <React.Fragment>
    <section id="footer">
              <p> Copyrights 2020. Reserved by Outbuzz Marketing</p>
    </section>
      </React.Fragment>
    );
  }
}
 
export default Footer;