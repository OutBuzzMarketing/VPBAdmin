import React, { Component } from 'react';
import CompetitionTable from '../Components/CompetitionTable';

class Intro extends Component {
    render() {
        return (
            <React.Fragment>
                <CompetitionTable />
            </React.Fragment>
        );
    }
}

export default Intro;