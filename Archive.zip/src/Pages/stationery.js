import React, { Component } from 'react';
import StationeryTable from '../Components/StationeryTable';

class Intro extends Component {
    render() {
        return (
            <React.Fragment>
                <StationeryTable />
            </React.Fragment>
        );
    }
}

export default Intro;