import React, { Component } from 'react';
import DashboardTable from '../Components/DashboardTable';

class Intro extends Component {
    render() {
        return (
            <React.Fragment>
                <DashboardTable />
            </React.Fragment>
        );
    }
}

export default Intro;