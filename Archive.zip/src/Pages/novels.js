import React, { Component } from 'react';
import NovelsTable from '../Components/NovelsTable';

class Intro extends Component {
    render() {
        return (
            <React.Fragment>
                <NovelsTable />
            </React.Fragment>
        );
    }
}

export default Intro;