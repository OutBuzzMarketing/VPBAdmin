import React, { Component } from 'react';
import TbTable from '../Components/TbTable';

class Intro extends Component {
    render() {
        return (
            <React.Fragment>
                <TbTable />
            </React.Fragment>
        );
    }
}

export default Intro;