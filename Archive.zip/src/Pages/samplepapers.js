import React, { Component } from 'react';
import SpTable from '../Components/SpTable';

class Intro extends Component {
    render() {
        return (
            <React.Fragment>
                <SpTable />
            </React.Fragment>
        );
    }
}

export default Intro;