import React, { Component } from 'react';
import NcertTable from '../Components/NcertTable';

class Intro extends Component {
    render() {
        return (
            <React.Fragment>
                <NcertTable />
            </React.Fragment>
        );
    }
}

export default Intro;